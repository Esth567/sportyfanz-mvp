(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[884],{3175:(e,a,t)=>{"use strict";t.d(a,{default:()=>i});var s=t(5155),r=t(7529),n=t(2115);function i(){let[e,a]=(0,n.useState)(""),[t,i]=(0,n.useState)(""),[o,l]=(0,n.useState)(!1),[d,c]=(0,n.useState)(""),[f,p]=(0,n.useState)(""),[u,h]=(0,n.useState)(null),[x,m]=(0,n.useState)(null),[g,b]=(0,n.useState)(!1),[j,y]=(0,n.useState)([]),[w,v]=(0,n.useState)(!0),[S,N]=(0,n.useState)(""),[k,E]=(0,n.useState)(null),[P,C]=(0,n.useState)("SUPPORT"),[T,O]=(0,n.useState)(null);async function A(s){if(s.preventDefault(),c(""),p(""),h(null),m(null),b(!1),e.trim().length<2)return void c("Enter the staff member's full name.");if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(t.trim()))return void c("Enter a valid work email address.");l(!0);try{let s=await (0,r.n)("/api/admin/staff",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:e.trim(),email:t.trim().toLowerCase(),staffRole:P})}),n=await s.json();if(!s.ok)throw Error(n.error||"Unable to create staff account.");m(n.staff),h(n.credentials),p("Staff account created successfully."),a(""),i(""),C("SUPPORT"),await z()}catch(e){c(e instanceof Error?e.message:"Something went wrong. Please try again.")}finally{l(!1)}}async function R(){if(u)try{await navigator.clipboard.writeText(`SportyFanz Staff Login
Username: ${u.username}
Temporary password: ${u.temporaryPassword}
Login page: /admin/login
Please change the temporary password immediately after signing in.`),b(!0)}catch{c("Could not copy automatically. Select and copy the credentials manually.")}}async function z(){v(!0),N("");try{let e=await (0,r.n)("/api/admin/staff",{cache:"no-store"}),a=await e.json();if(!e.ok)throw Error(a.error||"Unable to load staff accounts.");y(a.staff??[])}catch(e){N(e instanceof Error?e.message:"Unable to load staff accounts.")}finally{v(!1)}}async function U(e,a){O(e),N("");try{let t=await (0,r.n)(`/api/admin/staff/${e}`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({staffRole:a})}),s=await t.json();if(!t.ok)throw Error(s.error||"Unable to update staff role.");await z()}catch(e){N(e instanceof Error?e.message:"Unable to update staff role.")}finally{O(null)}}async function I(e,a){E(e),N("");try{let t=await (0,r.n)(`/api/admin/staff/${e}`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({status:a})}),s=await t.json();if(!t.ok)throw Error(s.error||"Unable to update staff status.");await z()}catch(e){N(e instanceof Error?e.message:"Unable to update staff status.")}finally{E(null)}}return(0,n.useEffect)(()=>{let e=!1;return async function(){N("");try{let a=await (0,r.n)("/api/admin/staff",{cache:"no-store"}),t=await a.json();if(!a.ok)throw Error(t.error||"Unable to load staff accounts.");e||y(t.staff??[])}catch(a){e||N(a instanceof Error?a.message:"Unable to load staff accounts.")}finally{e||v(!1)}}(),()=>{e=!0}},[]),(0,s.jsxs)("div",{className:"staff-workspace",children:[(0,s.jsxs)("section",{className:"staff-panel",children:[(0,s.jsxs)("div",{className:"staff-panel-heading",children:[(0,s.jsxs)("div",{children:[(0,s.jsx)("span",{className:"staff-icon",children:"＋"}),(0,s.jsx)("h2",{children:"Create a staff account"}),(0,s.jsx)("p",{children:"Only authorised administrators can create internal staff accounts."})]}),(0,s.jsx)("span",{className:"staff-access-badge",children:"ADMIN ONLY"})]}),(0,s.jsxs)("form",{onSubmit:A,className:"staff-form",children:[(0,s.jsxs)("label",{children:["Full name",(0,s.jsx)("input",{value:e,onChange:e=>a(e.target.value),placeholder:"Enter staff member's name",autoComplete:"name",maxLength:100,required:!0})]}),(0,s.jsxs)("label",{children:["Work email",(0,s.jsx)("input",{type:"email",value:t,onChange:e=>i(e.target.value),placeholder:"staff@company.com",autoComplete:"email",maxLength:254,required:!0})]}),(0,s.jsxs)("label",{children:["Staff role",(0,s.jsxs)("select",{value:P,onChange:e=>C(e.target.value),required:!0,children:[(0,s.jsx)("option",{value:"SUPPORT",children:"Support"}),(0,s.jsx)("option",{value:"OPERATIONS",children:"Operations"}),(0,s.jsx)("option",{value:"CONTENT_MODERATION",children:"Content Moderation"}),(0,s.jsx)("option",{value:"SUPER_ADMIN",children:"Super Admin"})]})]}),(0,s.jsxs)("div",{className:"staff-form-note",children:[(0,s.jsx)("strong",{children:"Security notice"}),(0,s.jsx)("p",{children:"A unique username and temporary password will be generated. The staff member must change the password at first login."})]}),d&&(0,s.jsx)("div",{className:"staff-alert staff-alert-error",role:"alert",children:d}),f&&(0,s.jsx)("div",{className:"staff-alert staff-alert-success",role:"status",children:f}),(0,s.jsx)("button",{className:"staff-primary-button",disabled:o,children:o?"Creating account...":"＋ Create staff account"})]})]}),u&&x&&(0,s.jsxs)("section",{className:"staff-panel staff-credentials-panel",children:[(0,s.jsxs)("div",{className:"staff-panel-heading",children:[(0,s.jsxs)("div",{children:[(0,s.jsx)("span",{className:"staff-icon",children:"✓"}),(0,s.jsx)("h2",{children:"Account created"}),(0,s.jsx)("p",{children:"Share these credentials securely with the staff member."})]}),(0,s.jsx)("span",{className:"staff-access-badge",children:"ACTIVE"})]}),(0,s.jsxs)("div",{className:"staff-created-details",children:[(0,s.jsxs)("div",{children:[(0,s.jsx)("span",{children:"Staff member"}),(0,s.jsx)("strong",{children:x.name})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)("span",{children:"Work email"}),(0,s.jsx)("strong",{children:x.email})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)("span",{children:"Username"}),(0,s.jsx)("strong",{children:u.username})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)("span",{children:"Temporary password"}),(0,s.jsx)("strong",{className:"staff-temp-password",children:u.temporaryPassword})]})]}),(0,s.jsxs)("div",{className:"staff-form-note",children:[(0,s.jsx)("strong",{children:"Important"}),(0,s.jsx)("p",{children:"This temporary password is displayed only after account creation. Store it securely and do not send it through a public channel. The staff member must change it after signing in."})]}),(0,s.jsx)("button",{type:"button",className:"staff-primary-button",onClick:R,children:g?"✓ Credentials copied":"Copy login credentials"}),(0,s.jsx)("a",{className:"staff-login-link",href:"/admin/login",children:"Open staff login →"})]}),(0,s.jsxs)("section",{className:"staff-panel",children:[(0,s.jsx)("div",{className:"staff-panel-heading",children:(0,s.jsxs)("div",{children:[(0,s.jsx)("span",{className:"staff-icon",children:"♙"}),(0,s.jsx)("h2",{children:"Staff directory"}),(0,s.jsx)("p",{children:"Staff listing and account-status controls will be connected to the protected staff API next."})]})}),(0,s.jsxs)("section",{className:"staff-directory",children:[(0,s.jsxs)("div",{className:"staff-directory-heading",children:[(0,s.jsxs)("div",{children:[(0,s.jsx)("h2",{children:"Staff Directory"}),(0,s.jsx)("p",{children:"Manage staff accounts and authorised access."})]}),(0,s.jsx)("button",{type:"button",onClick:()=>void z(),children:"Refresh"})]}),S&&(0,s.jsx)("p",{role:"alert",className:"staff-error",children:S}),w?(0,s.jsx)("p",{children:"Loading staff accounts..."}):0===j.length?(0,s.jsx)("p",{children:"No staff accounts found."}):(0,s.jsx)("div",{className:"staff-table-wrap",children:(0,s.jsxs)("table",{className:"staff-table",children:[(0,s.jsx)("thead",{children:(0,s.jsxs)("tr",{children:[(0,s.jsx)("th",{children:"Staff member"}),(0,s.jsx)("th",{children:"Username"}),(0,s.jsx)("th",{children:"Role"}),(0,s.jsx)("th",{children:"Status"}),(0,s.jsx)("th",{children:"Last login"}),(0,s.jsx)("th",{children:"Access"})]})}),(0,s.jsx)("tbody",{children:j.map(e=>(0,s.jsxs)("tr",{children:[(0,s.jsxs)("td",{children:[(0,s.jsx)("strong",{children:e.name}),(0,s.jsx)("small",{children:e.email})]}),(0,s.jsx)("td",{children:e.username}),(0,s.jsxs)("td",{children:[(0,s.jsxs)("select",{"aria-label":`Role for ${e.name}`,value:e.staffRole,disabled:T===e.id||k===e.id,onChange:a=>void U(e.id,a.target.value),children:[(0,s.jsx)("option",{value:"SUPER_ADMIN",children:"Super Admin"}),(0,s.jsx)("option",{value:"OPERATIONS",children:"Operations"}),(0,s.jsx)("option",{value:"CONTENT_MODERATION",children:"Content Moderation"}),(0,s.jsx)("option",{value:"SUPPORT",children:"Support"})]}),T===e.id&&(0,s.jsx)("small",{children:"Saving role…"})]}),(0,s.jsx)("td",{children:(0,s.jsx)("span",{className:`staff-status staff-status-${e.status.toLowerCase()}`,children:e.status})}),(0,s.jsx)("td",{children:e.lastLoginAt?new Date(e.lastLoginAt).toLocaleString():"Never"}),(0,s.jsxs)("td",{children:["DELETED"!==e.status&&(0,s.jsx)("button",{type:"button",disabled:k===e.id,onClick:()=>void I(e.id,"ACTIVE"===e.status?"SUSPENDED":"ACTIVE"),children:k===e.id?"Updating...":"ACTIVE"===e.status?"Suspend":"Activate"}),e.mustChangePassword&&(0,s.jsx)("small",{children:" Password change required"})]})]},e.id))})]})})]})]}),(0,s.jsx)("style",{children:`
        .staff-workspace {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 22px;
          align-items: start;
        }
        .staff-panel {
          min-width: 0;
          padding: 25px;
          background: #171a26;
          border: 1px solid #292d3d;
          border-radius: 16px;
          box-sizing: border-box;
        }
        .staff-panel-heading {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 16px;
          margin-bottom: 24px;
        }
        .staff-panel-heading h2 {
          margin: 13px 0 8px;
          font-size: 19px;
        }
        .staff-panel-heading p {
          margin: 0;
          color: #a3a9bd;
          font-size: 13px;
          line-height: 1.6;
        }
        .staff-icon {
          display: grid;
          place-items: center;
          width: 38px;
          height: 38px;
          border-radius: 11px;
          background: #302a1d;
          color: #f5b82e;
          font-size: 21px;
        }
        .staff-access-badge {
          flex-shrink: 0;
          padding: 7px 9px;
          border-radius: 7px;
          background: #302a1d;
          color: #f5b82e;
          font-size: 9px;
          font-weight: 800;
          letter-spacing: 1px;
        }
        .staff-form { display: grid; gap: 19px; }
        .staff-form label {
          display: grid;
          gap: 9px;
          color: #e8eaf2;
          font-size: 13px;
          font-weight: 700;
        }
        .staff-form input {
          width: 100%;
          min-width: 0;
          box-sizing: border-box;
          padding: 13px 14px;
          border: 1px solid #383d50;
          border-radius: 9px;
          outline: none;
          background: #10121b;
          color: #f7f8fc;
          font: inherit;
          font-weight: 400;
        }
        .staff-form input:focus {
          border-color: #f5b82e;
          box-shadow: 0 0 0 3px #f5b82e20;
        }
        .staff-form input::placeholder { color: #777f96; }
        .staff-form-note {
          padding: 14px;
          border: 1px solid #383328;
          border-radius: 10px;
          background: #211f1b;
        }
        .staff-form-note strong {
          color: #f5c85e;
          font-size: 12px;
        }
        .staff-form-note p {
          margin: 7px 0 0;
          color: #c3c5cf;
          font-size: 12px;
          line-height: 1.7;
        }
          .staff-form select {
            width: 100%;
            min-width: 0;
            box-sizing: border-box;
            padding: 13px 14px;
            border: 1px solid #383d50;
            border-radius: 9px;
            outline: none;
            background: #10121b;
            color: #f7f8fc;
            font: inherit;
          }

          .staff-form select:focus {
             border-color: #f5b82e;
             box-shadow: 0 0 0 3px #f5b82e20;
           }
        .staff-table select {
         max-width: 190px;
         padding: 7px 9px;
         border: 1px solid #383d50;
         border-radius: 7px;
         background: #10121b;
         color: #f7f8fc;
         font-size: 12px;
       }

        .staff-table select:disabled {
           opacity: 0.6;
           cursor: wait;
         }
        .staff-alert {
          padding: 12px 14px;
          border-radius: 9px;
          font-size: 13px;
          line-height: 1.5;
        }
        .staff-alert-error {
          border: 1px solid #7c343d;
          background: #321b22;
          color: #ffb7c0;
        }
        .staff-alert-success {
          border: 1px solid #286b50;
          background: #152d25;
          color: #a5efc9;
        }
        .staff-primary-button {
          display: inline-flex;
          justify-content: center;
          align-items: center;
          width: 100%;
          padding: 13px 16px;
          border: 0;
          border-radius: 9px;
          background: #f5b82e;
          color: #10121b;
          font-size: 13px;
          font-weight: 800;
          cursor: pointer;
        }
        .staff-primary-button:hover { background: #ffd064; }
        .staff-primary-button:disabled {
          cursor: wait;
          opacity: .65;
        }
        .staff-credentials-panel { border-color: #6a5526; }
        .staff-created-details {
          display: grid;
          gap: 0;
          margin-bottom: 18px;
          border: 1px solid #333747;
          border-radius: 10px;
          overflow: hidden;
        }
        .staff-created-details > div {
          display: grid;
          gap: 6px;
          padding: 13px;
          border-bottom: 1px solid #333747;
        }
        .staff-created-details > div:last-child { border-bottom: 0; }
        .staff-created-details span {
          color: #a3a9bd;
          font-size: 11px;
        }
        .staff-created-details strong {
          overflow-wrap: anywhere;
          font-size: 13px;
        }
        .staff-temp-password {
          color: #f5c85e;
          user-select: all;
        }
        .staff-login-link {
          display: block;
          margin-top: 17px;
          color: #f5b82e;
          text-align: center;
          text-decoration: none;
          font-size: 13px;
        }
        .staff-directory-placeholder {
          display: grid;
          justify-items: center;
          padding: 34px 14px;
          border: 1px dashed #383d50;
          border-radius: 12px;
          text-align: center;
        }
        .staff-directory-placeholder > span {
          color: #f5b82e;
          font-size: 29px;
        }
        .staff-directory-placeholder strong {
          margin-top: 12px;
          font-size: 14px;
        }
        .staff-directory-placeholder p {
          max-width: 290px;
          color: #a3a9bd;
          font-size: 12px;
          line-height: 1.7;
        }
          
       .staff-directory {
         margin-top: 28px;
         padding: 24px;
         border: 1px solid #343434;
         border-radius: 16px;
         background: #171717;
         color: #f5f5f5;
        }

.staff-directory-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 20px;
}

.staff-directory-heading h2 {
  margin: 0 0 6px;
}

.staff-directory-heading p,
.staff-table small {
  display: block;
  color: #a7a7a7;
  font-size: 13px;
  margin-top: 5px;
}

.staff-directory button {
  padding: 9px 13px;
  border: 1px solid #b88b2e;
  border-radius: 8px;
  background: transparent;
  color: #f3c969;
  cursor: pointer;
}

.staff-directory button:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}

.staff-table-wrap {
  width: 100%;
  overflow-x: auto;
}

.staff-table {
  width: 100%;
  border-collapse: collapse;
  text-align: left;
}

.staff-table th,
.staff-table td {
  padding: 14px 12px;
  border-bottom: 1px solid #303030;
  vertical-align: top;
  white-space: nowrap;
}

.staff-table th {
  color: #c8a34d;
  font-size: 12px;
  text-transform: uppercase;
}
.staff-role-badge {
  display: inline-block;
  padding: 5px 9px;
  border: 1px solid #5a4a28;
  border-radius: 7px;
  background: #302a1d;
  color: #f5c85e;
  font-size: 11px;
  font-weight: 700;
}
.staff-status {
  display: inline-block;
  padding: 5px 9px;
  border-radius: 20px;
  font-size: 11px;
  font-weight: 700;
}

.staff-status-active {
  color: #9ce6b0;
  background: #173c27;
}

.staff-status-suspended {
  color: #ffcf91;
  background: #49351b;
}

.staff-status-deleted {
  color: #ffaaaa;
  background: #482323;
}

.staff-error {
  color: #ffaaaa;
  margin: 12px 0;
}

        @media (max-width: 900px) {
          .staff-workspace { grid-template-columns: 1fr; }
        }
        @media (max-width: 480px) {
          .staff-panel { padding: 18px; }
          .staff-panel-heading { flex-direction: column; }
        }
      `})]})}},3321:(e,a,t)=>{"use strict";var s=t(4645);t.o(s,"usePathname")&&t.d(a,{usePathname:function(){return s.usePathname}}),t.o(s,"useRouter")&&t.d(a,{useRouter:function(){return s.useRouter}}),t.o(s,"useSearchParams")&&t.d(a,{useSearchParams:function(){return s.useSearchParams}})},3429:(e,a,t)=>{Promise.resolve().then(t.bind(t,3175)),Promise.resolve().then(t.bind(t,6641))},6641:(e,a,t)=>{"use strict";t.d(a,{default:()=>l});var s=t(5155),r=t(2115),n=t(3321),i=t(7529);let o={SUPER_ADMIN:["staff:read","staff:manage","rewards:manage","predictions:manage","trivia:manage","polls:manage","fanrooms:manage","content:moderate","fans:support","players:manage","kyc:manage"],OPERATIONS:["rewards:manage","predictions:manage","kyc:manage"],CONTENT_MODERATION:["trivia:manage","polls:manage","content:moderate"],SUPPORT:["fans:support"]};function l({permission:e,children:a}){let t=(0,n.useRouter)(),[d,c]=(0,r.useState)(!1),[f,p]=(0,r.useState)(!0);return((0,r.useEffect)(()=>{let a=!0;return async function(){try{let s=await (0,i.n)("/api/admin/me",{cache:"no-store"}),r=await s.json().catch(()=>({}));if(!a)return;if(403===s.status&&"PASSWORD_CHANGE_REQUIRED"===r.code)return void t.replace("/admin/change-password");if(401===s.status||!s.ok)return void t.replace("/admin/login");let n=r.admin?.staffRole;if(!n||!o[n]?.includes(e))return void t.replace("/admin/dashboard");c(!0)}catch{a&&t.replace("/admin/login")}finally{a&&p(!1)}}(),()=>{a=!1}},[e,t]),f||!d)?(0,s.jsx)("main",{style:{minHeight:"100vh",display:"grid",placeItems:"center",background:"#10121b",color:"#f5b82e",fontFamily:"Lato, Arial, sans-serif"},children:"Verifying staff access..."}):(0,s.jsx)(s.Fragment,{children:a})}},7529:(e,a,t)=>{"use strict";t.d(a,{n:()=>r});let s="https://api.sportyfanz.com".replace(/\/+$/,"")??0;function r(e,a={}){return fetch(function(e){if(/^https?:\/\//i.test(e))return e;let a=e.startsWith("/")?e:`/${e}`;return s?`${s}${a}`:a}(e),{...a,credentials:a.credentials??"include"})}}},e=>{e.O(0,[441,794,358],()=>e(e.s=3429)),_N_E=e.O()}]);