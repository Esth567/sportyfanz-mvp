(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[957],{3321:(a,e,i)=>{"use strict";var n=i(4645);i.o(n,"usePathname")&&i.d(e,{usePathname:function(){return n.usePathname}}),i.o(n,"useRouter")&&i.d(e,{useRouter:function(){return n.useRouter}}),i.o(n,"useSearchParams")&&i.d(e,{useSearchParams:function(){return n.useSearchParams}})},4111:(a,e,i)=>{"use strict";i.r(e),i.d(e,{default:()=>c});var n=i(5155),s=i(2115),t=i(3321),r=i(7529);function d(){let[a,e]=(0,s.useState)(!1),[i,d]=(0,s.useState)(""),o=(0,t.useRouter)();async function l(){e(!0),d("");try{if(!(await (0,r.n)("/api/admin/logout",{method:"POST",cache:"no-store"})).ok)throw Error("Unable to log out. Please try again.");o.replace("/admin/login"),o.refresh()}catch{d("Logout failed. Please try again."),e(!1)}}return(0,n.jsxs)("div",{children:[(0,n.jsx)("button",{type:"button",onClick:l,disabled:a,style:{background:"#303447",color:"#ffffff",border:"1px solid #454b60",borderRadius:8,padding:"10px 16px",fontWeight:600,cursor:a?"wait":"pointer",opacity:a?.7:1},children:a?"Signing out...":"Logout"}),i&&(0,n.jsx)("p",{role:"alert",style:{color:"#ff7777",fontSize:12},children:i})]})}let o={SUPER_ADMIN:["staff:read","staff:manage","rewards:manage","predictions:manage","trivia:manage","polls:manage","fanrooms:manage","content:moderate","fans:support","players:manage","kyc:manage"],OPERATIONS:["rewards:manage","predictions:manage","kyc:manage"],CONTENT_MODERATION:["trivia:manage","polls:manage","content:moderate"],SUPPORT:["fans:support"]},l=[{title:"Trivia Management",description:"Create questions, manage answer options, set points, and publish trivia.",status:"Ready to connect",icon:"?",href:"/admin/dashboard/trivia",permission:"trivia:manage"},{title:"Rewards Management",description:"Manage reward availability, inventory, and redemption requests.",status:"Existing rewards API",icon:"★",href:"/admin/dashboard/rewards",permission:"rewards:manage"},{title:"Polls Management",description:"Create polls, manage options, and monitor fan participation.",status:"Existing polls API",icon:"◉",href:"/admin/dashboard/polls",permission:"polls:manage"},{title:"Fan Room Management",description:"Create fan communities, manage room availability, and monitor member activity.",status:"Fan Rooms API",icon:"♧",href:"/admin/dashboard/fanrooms",permission:"fanrooms:manage"},{title:"Predictions",description:"Manage prediction activities and review fan submissions.",status:"Existing predictions API",icon:"↗",href:"/admin/dashboard/predictions",permission:"predictions:manage"},{title:"Fan Management",description:"View fan accounts and account status.",status:"Planned",icon:"♙",href:"/admin/dashboard/fans",permission:"fans:support"},{title:"Staff Management",description:"Create staff accounts, view staff details, and manage authorised access.",status:"Staff administration",icon:"♙",href:"/admin/dashboard/staff",permission:"staff:manage"},{title:"KYC Management",description:"Review fan verification submissions, approve or reject KYC, and manage verification rewards.",status:"KYC review system",icon:"✓",href:"/admin/dashboard/kyc",permission:"kyc:manage"},{title:"Players Management",description:"Create player profiles, assign teams, and manage the players shown in Discover.",status:"Player directory",icon:"♙",href:"/admin/dashboard/players",permission:"players:manage"}];function c(){let a=(0,t.useRouter)(),[e,i]=(0,s.useState)(null),[c,m]=(0,s.useState)(!0);if((0,s.useEffect)(()=>{let e=!0;return async function(){try{let n=await (0,r.n)("/api/admin/me",{cache:"no-store"}),s=await n.json().catch(()=>({}));if(!e)return;if(403===n.status&&"PASSWORD_CHANGE_REQUIRED"===s.code)return void a.replace("/admin/change-password");if(401===n.status||!n.ok)return void a.replace("/admin/login");let t=s.admin,d=t?.staffRole;if(!d||!o[d])return void a.replace("/admin/login");i({name:t.name??null,email:t.email,staffRole:d})}catch{e&&a.replace("/admin/login")}finally{e&&m(!1)}}(),()=>{e=!1}},[a]),c||!e)return(0,n.jsx)("main",{style:{minHeight:"100vh",display:"grid",placeItems:"center",background:"#10121b",color:"#f5b82e",fontFamily:"Lato, Arial, sans-serif"},children:"Verifying staff access..."});let p=l.filter(a=>o[e.staffRole].includes(a.permission));return(0,n.jsxs)("main",{className:"admin-shell",children:[(0,n.jsxs)("aside",{className:"admin-sidebar",children:[(0,n.jsxs)("div",{className:"admin-brand",children:[(0,n.jsx)("span",{className:"admin-brand-mark",children:"S"}),(0,n.jsxs)("span",{children:[(0,n.jsx)("strong",{children:"SportyFanz"}),(0,n.jsx)("small",{children:"STAFF ADMIN"})]})]}),(0,n.jsx)("p",{className:"admin-nav-label",children:"WORKSPACE"}),(0,n.jsxs)("nav",{className:"admin-nav",children:[(0,n.jsxs)("a",{className:"admin-nav-link active",href:"/admin/dashboard",children:[(0,n.jsx)("span",{children:"⌂"})," Overview"]}),p.map(a=>(0,n.jsxs)("a",{className:"admin-nav-link",href:a.href,children:[(0,n.jsx)("span",{children:a.icon}),a.title.replace(" Management","")]},a.title))]}),(0,n.jsxs)("div",{className:"admin-sidebar-bottom",children:[(0,n.jsx)(d,{}),(0,n.jsxs)("div",{className:"admin-sidebar-footer",children:[(0,n.jsx)("span",{className:"admin-status-dot"}),"Internal staff portal"]})]})]}),(0,n.jsxs)("section",{className:"admin-main",children:[(0,n.jsxs)("header",{className:"admin-topbar",children:[(0,n.jsxs)("div",{children:[(0,n.jsx)("p",{className:"admin-eyebrow",children:"SPORTYFANZ OPERATIONS"}),(0,n.jsx)("h1",{children:"Dashboard"})]}),(0,n.jsxs)("div",{className:"admin-account",children:[(0,n.jsx)("span",{className:"admin-avatar",children:(e.name||e.email).charAt(0).toUpperCase()}),(0,n.jsxs)("span",{children:[(0,n.jsx)("strong",{children:e.name||"Staff Admin"}),(0,n.jsx)("small",{children:e.email})]})]})]}),(0,n.jsxs)("div",{className:"admin-content",children:[(0,n.jsxs)("section",{className:"admin-welcome",children:[(0,n.jsxs)("div",{children:[(0,n.jsx)("p",{className:"admin-eyebrow",children:"INTERNAL WORKSPACE"}),(0,n.jsx)("h2",{children:"Welcome to SportyFanz Admin"}),(0,n.jsx)("p",{children:"Manage the content, rewards, and activities that power the fan experience from one central workspace."})]}),(0,n.jsx)("div",{className:"admin-welcome-mark","aria-hidden":"true",children:"SF"})]}),(0,n.jsxs)("div",{className:"admin-section-heading",children:[(0,n.jsxs)("div",{children:[(0,n.jsx)("h2",{children:"Management workspace"}),(0,n.jsx)("p",{children:"Choose an area to manage."})]}),(0,n.jsx)("span",{className:"admin-role-pill",children:e.staffRole.replaceAll("_"," ")})]}),(0,n.jsx)("div",{className:"admin-grid",children:p.map(a=>(0,n.jsxs)("article",{className:"admin-card",children:[(0,n.jsx)("div",{className:"admin-card-icon",children:a.icon}),(0,n.jsx)("h3",{children:a.title}),(0,n.jsx)("p",{children:a.description}),(0,n.jsx)("span",{className:"admin-card-status",children:a.status}),(0,n.jsxs)("a",{className:"admin-card-link",href:a.href,children:["Open section ",(0,n.jsx)("span",{"aria-hidden":"true",children:"→"})]})]},a.title))})]})]}),(0,n.jsx)("style",{children:`
        .admin-shell {
          min-height: 100vh;
          display: flex;
          background: #10121b;
          color: #f7f8fc;
          font-family: Lato, Arial, sans-serif;
        }
        .admin-sidebar {
          width: 245px;
          flex-shrink: 0;
          display: flex;
          flex-direction: column;
          padding: 28px 18px;
          box-sizing: border-box;
          background: #171a26;
          border-right: 1px solid #292d3d;
        }
        .admin-brand {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 0 8px 34px;
        }
        .admin-brand-mark {
          display: grid;
          place-items: center;
          width: 42px;
          height: 42px;
          border-radius: 12px;
          background: #f5b82e;
          color: #10121b;
          font-size: 23px;
          font-weight: 900;
        }
        .admin-brand strong, .admin-brand small,
        .admin-account strong, .admin-account small {
          display: block;
        }
        .admin-brand strong { font-size: 16px; }
        .admin-brand small {
          margin-top: 5px;
          color: #a4abc0;
          font-size: 10px;
          letter-spacing: 1.5px;
        }
        .admin-nav-label, .admin-eyebrow {
          color: #a3a9bd;
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 1.7px;
        }
        .admin-nav-label { padding: 0 10px; margin-bottom: 12px; }
        .admin-nav { display: grid; gap: 7px; }
        .admin-sidebar-bottom {
           margin-top: auto;
           padding-top: 28px;
           display: grid;
           gap: 18px;
         }

        .admin-sidebar-bottom button {
          width: 100%;
          text-align: left;
        }
        .admin-nav-link {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px 10px;
          border-radius: 9px;
          color: #c0c5d5;
          text-decoration: none;
          font-size: 13px;
        }
        .admin-nav-link span {
          width: 20px;
          text-align: center;
          color: #f5b82e;
        }
        .admin-nav-link:hover, .admin-nav-link.active {
          background: #282c3c;
          color: #fff;
        }
        .admin-sidebar-footer {
          display: flex;
          align-items: center;
          gap: 9px;
          margin-top: auto;
          padding: 20px 8px 0;
          color: #a3a9bd;
          font-size: 11px;
        }
        .admin-status-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #45cf91;
        }
        .admin-main { flex: 1; min-width: 0; }
        .admin-topbar {
          min-height: 95px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 20px;
          padding: 22px 36px;
          border-bottom: 1px solid #292d3d;
          box-sizing: border-box;
        }
        .admin-eyebrow { margin: 0 0 8px; }
        .admin-topbar h1 { margin: 0; font-size: 24px; }
        .admin-account { display: flex; align-items: center; gap: 11px; }
        .admin-avatar {
          display: grid;
          place-items: center;
          width: 38px;
          height: 38px;
          border-radius: 50%;
          background: #34394d;
          color: #f5b82e;
          font-weight: 800;
        }
        .admin-account strong { font-size: 13px; }
        .admin-account small {
          margin-top: 4px;
          color: #a3a9bd;
          font-size: 11px;
        }
        .admin-content { max-width: 1500px; margin: auto; padding: 32px 36px; }
        .admin-welcome {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 24px;
          padding: 30px;
          border: 1px solid #393548;
          border-radius: 16px;
          background: linear-gradient(120deg, #282438, #1c2030);
        }
        .admin-welcome h2 { margin: 0 0 12px; font-size: 25px; }
        .admin-welcome p:last-child {
          max-width: 610px;
          margin: 0;
          color: #c0c5d5;
          font-size: 14px;
          line-height: 1.7;
        }
        .admin-welcome-mark {
          display: grid;
          place-items: center;
          width: 76px;
          height: 76px;
          flex-shrink: 0;
          border: 1px solid #6a5830;
          border-radius: 20px;
          color: #f5b82e;
          font-size: 25px;
          font-weight: 900;
        }
        .admin-section-heading {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 16px;
          margin: 34px 0 18px;
        }
        .admin-section-heading h2 { margin: 0 0 7px; font-size: 18px; }
        .admin-section-heading p { margin: 0; color: #a3a9bd; font-size: 13px; }
        .admin-role-pill {
          padding: 8px 10px;
          border: 1px solid #5a4b2a;
          border-radius: 20px;
          color: #f5b82e;
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 1px;
        }
        .admin-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 18px;
        }
        .admin-card {
          display: flex;
          flex-direction: column;
          align-items: flex-start;
          min-height: 230px;
          padding: 22px;
          border: 1px solid #2e3243;
          border-radius: 14px;
          background: #191c29;
          box-sizing: border-box;
        }
        .admin-card-icon {
          display: grid;
          place-items: center;
          width: 40px;
          height: 40px;
          border-radius: 10px;
          background: #2b2b36;
          color: #f5b82e;
          font-size: 21px;
          font-weight: 800;
        }
        .admin-card h3 { margin: 17px 0 9px; font-size: 16px; }
        .admin-card p {
          margin: 0 0 14px;
          color: #aeb4c7;
          font-size: 12px;
          line-height: 1.7;
        }
        .admin-card-status {
          margin-top: auto;
          color: #8e96ad;
          font-size: 10px;
        }
        .admin-card-link {
          display: flex;
          justify-content: space-between;
          width: 100%;
          margin-top: 18px;
          padding-top: 14px;
          border-top: 1px solid #303447;
          color: #f5b82e;
          font-size: 12px;
          font-weight: 700;
          text-decoration: none;
        }
        .admin-card-link:hover { color: #ffda79; }
        .admin-footer {
          padding: 28px 0 4px;
          color: #777f97;
          font-size: 11px;
          text-align: center;
        }
        @media (max-width: 1050px) {
          .admin-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
          .admin-sidebar { width: 215px; }
          .admin-content { padding: 24px; }
          .admin-topbar { padding: 20px 24px; }
        }
        @media (max-width: 700px) {
          .admin-sidebar { display: none; }
          .admin-grid { grid-template-columns: 1fr; }
          .admin-topbar { align-items: flex-start; flex-direction: column; }
          .admin-content { padding: 18px; }
          .admin-welcome { padding: 22px; }
          .admin-welcome h2 { font-size: 21px; }
          .admin-welcome-mark { display: none; }
        }
      `})]})}},5799:(a,e,i)=>{Promise.resolve().then(i.bind(i,4111))},7529:(a,e,i)=>{"use strict";i.d(e,{n:()=>s});let n="https://api.sportyfanz.com".replace(/\/+$/,"")??0;function s(a,e={}){return fetch(function(a){if(/^https?:\/\//i.test(a))return a;let e=a.startsWith("/")?a:`/${a}`;return n?`${n}${e}`:e}(a),{...e,credentials:e.credentials??"include"})}}},a=>{a.O(0,[441,794,358],()=>a(a.s=5799)),_N_E=a.O()}]);